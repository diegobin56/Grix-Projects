//Termometro Casa Per lo Zio
// Con display 7 segmenti
//Autore : Diego Bincoletto
//Data: 16 Ottobre 2017

unsigned char i, u, DG[3]; DigNo;    // DG0 = decimale
long int R_NTC1, R_NTC2;
int T_int, T_dec;
char DG0, DG1, DG2;

// Debug _________________________
// Formula Definizione BITtime in funzione del Baudrate voluto
// (Fclock/Baudrate)/4.2177  (determinato empiricamente)
// Baudrate usato = 2400
#define BITtime 395

unsigned char strx(char *ss);
char str1[4];
//________________________________

// Tabella NTC -20/+50�C
const unsigned long int NTC_RES[71]={97083,91621,86501,81696,77189,72957,68983,65244,61736,58433,
                       55329,52407,49658,47065,44627,42327,40160,38113,36186,34369,
                       32650,31030,29498,28051,26683,25391,24170,23015,21918,20884,
                       19902,18970,18091,17256,16461,15710,15000,14325,13681,13073,
                       12491,11940,11421,10924,10448,10000,9574,9165,8779,8406,
                       8055,7722,7402,7096,6807,6532,6266,6017,5777,5546,
                       5324,5115,4916,4725,4543,4368,4201,4041,3888,3742,
                       3602};
const char Int_Time = 10;     // Int0 value

//----------------------------------------------------------------------------------------

unsigned short mask(unsigned short num) { // **************  7 segment Mask Common Cathode***********
 switch (num) {
   case 0 : return 0x3F;
   case 1 : return 0x06;
   case 2 : return 0x5B;
   case 3 : return 0x4F;
   case 4 : return 0x66;
   case 5 : return 0x6D;
   case 6 : return 0x7D;
   case 7 : return 0x07;
   case 8 : return 0x7F;
   case 9 : return 0x6F;
   } //case end
} // End Mask

void  interrupt(void) {              // ************** ISR ***********

    if (T0IF) {               // L'interrupt � stato causato da un overflow del timer0
    TMR0 = Int_Time;          // Reimposto Timer0

    PORTC = 0x00;
    PORTB = DigNo;            // Select Tens Digit
    delay_us(50);
    PORTC = DG[u];

    DigNo = DigNo << 1;       //  move to next digit
    u ++;

    if (DigNo == 8) {
       DigNo = 1;             // return to 1st digit
       u = 0;
   }
  }
  
  INTCON.T0IF = 0;            // Reset Tomer0 Int Flag
  INTCON.TMR0IE = 1;          // T0 Overflow INT enable
 }                            // end of interrupt service routine

void ReadNTC(){   // **************  Read NTC  ***********
 char i,OffT;
 unsigned int  ValAD1, ValAD2;
 long ADCval1, ADCval2, R1, R2, Rx;
 unsigned int NTC_VAL[5];

ADCval1 =0, ADCval2 =0;
OffT =20;                                 // valore inizio tabella temperatura
R1 = 10000; //9960;                       // valore resistenza rif. 1
//for (i=0; i<5; i++)  NTC_VAL[i] = 0;
  
  for (i=0; i<5; i++) {
// NTC_VAL[i] = ADC_Read(0);              // Read n analog values from channel 1

//  ADCval1 = ADC_Read(0);

    ValAD1 = ADC_Read(0);                  // Read n analog values from channel 1//
    ADCval1 = ValAD1+ ADCval1;
   }
    ADCval1 = ADCval1/5;                 // average of n readings

    R_NTC1 = (R1 * ADCval1);
    R_NTC1 = R_NTC1 / (1023 - ADCval1);   // Calcola Resistenza NTC1

}  // End leggi NTC -----------------------------------------------


long CalcTemp(long ResNTC){   // **************  Calculate temperature ***********
 long int Rtab_diff, Rntc_diff, r_h, r_l, Rw, OffT;
 signed int Temp_NTC;
 int gh;
 long int a, b;

  for(gh=0; gh<71; gh++) {                                             // Individua limiti resistenza su 71 valori
   Rw = NTC_RES[gh];
   if ( NTC_RES[gh] >= ResNTC && NTC_RES[gh+1] <= ResNTC ) {           // individua i valori sotto e sopra
        r_h=NTC_RES[gh+1];                                             // OffT � l'offset della temperatura minima in tabella
        r_l=NTC_RES[gh];
        break;
        }
  }

    if ( gh < 71 )
     {
        Rtab_diff = r_l - r_h;                                        // calcola Rdiff  1�C
        Rntc_diff =  ResNTC - r_h;                                    // calcola Rdiff da aggiungere

      T_int = (gh) - 20 ;                                             // intero di temp
      T_dec =  (Rntc_diff*10 / Rtab_diff);

     if (T_dec > 0 && T_dec < 10 ) {                                  // decimale di temp
      T_dec = 10 - T_dec;}
     else {
      T_int= T_int + 1;
      T_dec = 0;
      }

  a=b;

     } else {
      T_int=99;                                                       // errore misura NTC =99.9�C
      T_dec=9;
      }
      
}  // End Calc Temp   -----------------------------------------------

// DEBUG #######################################################################
void Tx_Byte(unsigned char Data) {  //************* Invia 1 chrattere
  char mask;
  PORTC.F3 = 0;
  delay_us(BITtime);

  for (mask=0x01;mask!=0;mask=mask<<1)
  {
    if(Data&mask) PORTC.F3 = 1;
    else PORTC.F3 = 0;
    delay_us(BITtime);
  }
  PORTC.F3 = 1;
  delay_us(BITtime);
} //***************************************

unsigned char strx(char *ss) {   //************* Invia una stringa
Tx_Byte(*ss++);       // Invia primo carattere della stringa
delay_mS(10);
Tx_Byte(*ss++);       // continua con gli altri caratteri.....
delay_mS(10);
Tx_Byte(*ss++);
delay_mS(10);
Tx_Byte(*ss++);
delay_mS(10);
Tx_Byte(0x0D);  // Carrige Return  (da usare con terminal per andare a caporiga)
}  //***************************************}  //***************************************

unsigned char stTx(char *ss) {   //************* Invia una numero di 3 cifre
PORTC.F3 = 1;              // Setta pin TX alto
      str1[0] = '1';
      str1[1] = '2';
      str1[2] = '3';
        strx(str1);
}  //***************************************
// End DEBUG ###################################################################

void main() {
 long Temp1, Temp2;
 long int Lop;

  PORTA = 0x00;              // Turn OFF PortB
  PORTB = 0x00;              // Turn OFF PortB
  PORTC = 0x00;              // Turn OFF PortC
  
  OPTION_REG = 0x80;         // Timer0, Pre=256
  INTCON = 0;


  ADCON0 = 0xC1;             // ADC ON, RC oscill
  ADCON1 = 0x84;             // 0, 1 Analogico, resto Digitali  Vref = VDD
  
  TRISC = 0x00;              // Set PORTC direction to be output - Segments
  TRISB = 0x00;              // Set PORTB direction to be output - Lower 3 bits = Cathode
  TRISA  = 0b00000011;       // RA0 = NTC sensor - RA1 = Rref

 TMR0 = Int_Time;                   // 4ms
 INTCON.GIE = 1;             // Global INT enable
 INTCON.PEIE = 1;            // Peropheral INT enable
 INTCON.TMR0IE = 1;          // T0 Overflow INT enable

  ADC_Init_Advanced(_ADC_INTERNAL_REF);
  u = 0;                      // Select first digit of number
  DigNo = 1;                  // Select first display

 do {
  delay_mS(2000);
  ReadNTC();
  
//  R_NTC1 = 26550;
  CalcTemp(R_NTC1);

  DG0 = (T_int/10)%10;        // Extract Tens Digit
  DG1 = T_int-(DG0*10);       // Extract Ones Digit
  DG2 = T_dec;                // Decimal Digit

  DG[0] = mask(DG0);             // Convert to 7 segments
  DG[1] = mask(DG1);
  DG[2] = mask(DG2);
  
  Temp1=Temp1+1;
 }
 while(1);// loop

} // End Main